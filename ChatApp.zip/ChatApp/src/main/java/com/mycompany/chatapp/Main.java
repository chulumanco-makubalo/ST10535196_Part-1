// Main.java
package com.mycompany.chatapp;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        // Create an object of the Login class
        Login login = new Login();

        // --- REGISTRATION ---
        System.out.println("=== USER REGISTRATION ===");

        System.out.print("Enter a username: ");
        String username = input.nextLine();

        System.out.print("Enter a password: ");
        String password = input.nextLine();

        System.out.print("Enter your South African cellphone number (+27): ");
        String phone = input.nextLine();

        // Register user
        String response = login.registerUser(username, password, phone);
        System.out.println(response);

        // --- LOGIN ---
        System.out.println("\n=== USER LOGIN ===");

        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();

        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();

    

        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
        System.out.println(login.returnLoginStatus(loggedIn));
    }
}
 